package dev.lucachinou.stoppausemymusic.client;

import dev.lucachinou.stoppausemymusic.mixin.client.accessor.MusicTrackerAccessor;
import dev.lucachinou.stoppausemymusic.mixin.client.accessor.SoundManagerAccessor;
import dev.lucachinou.stoppausemymusic.mixin.client.accessor.SoundSystemAccessor;
import java.util.ArrayList;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_1142;
import net.minecraft.class_1144;
import net.minecraft.class_310;

public final class PersistentMusicState {
    private static final int TRANSITION_GRACE_TICKS = 40;

    private static class_1113 preservedMusic;
    private static int graceTicksRemaining;

    private PersistentMusicState() {
    }

    public static boolean preserveCurrentMusic(class_310 client) {
        if (client == null) {
            clear();
            return false;
        }

        return keepCurrentMusic(client.method_1538(), client.method_1483());
    }

    public static boolean keepCurrentMusic(class_1142 musicTracker, class_1144 soundManager) {
        class_1113 currentMusic = ((MusicTrackerAccessor) musicTracker).stoppausemymusic$getCurrent();
        if (currentMusic == null) {
            clear();
            return false;
        }

        preserve(currentMusic);
        return true;
    }

    public static void stopAllExceptCurrentMusic(class_1142 musicTracker, class_1144 soundManager) {
        class_1113 currentMusic = ((MusicTrackerAccessor) musicTracker).stoppausemymusic$getCurrent();
        if (currentMusic == null) {
            clear();
            soundManager.method_4881();
            return;
        }

        preserve(currentMusic);
        class_1140 soundSystem = ((SoundManagerAccessor) soundManager).stoppausemymusic$getSoundSystem();

        for (class_1113 sound : new ArrayList<>(((SoundSystemAccessor) soundSystem).stoppausemymusic$getSources().keySet())) {
            if (sound != currentMusic) {
                soundManager.method_4870(sound);
            }
        }
    }

    public static boolean shouldKeepPlaying(class_1113 currentMusic, class_1144 soundManager) {
        if (preservedMusic == null || currentMusic != preservedMusic) {
            return false;
        }

        if (soundManager.method_4877(currentMusic) || graceTicksRemaining > 0) {
            return true;
        }

        clear();
        return false;
    }

    public static void validate(class_1113 currentMusic, class_1144 soundManager) {
        if (preservedMusic == null) {
            return;
        }

        if (currentMusic != preservedMusic) {
            clear();
            return;
        }

        if (soundManager.method_4877(currentMusic)) {
            graceTicksRemaining = TRANSITION_GRACE_TICKS;
            return;
        }

        if (graceTicksRemaining > 0) {
            graceTicksRemaining--;
            return;
        }

        clear();
    }

    public static void clear() {
        preservedMusic = null;
        graceTicksRemaining = 0;
    }

    private static void preserve(class_1113 currentMusic) {
        preservedMusic = currentMusic;
        graceTicksRemaining = TRANSITION_GRACE_TICKS;
    }
}
