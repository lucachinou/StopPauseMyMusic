package dev.lucachinou.stoppausemymusic.client;

import dev.lucachinou.stoppausemymusic.mixin.client.accessor.MusicTrackerAccessor;
import dev.lucachinou.stoppausemymusic.mixin.client.accessor.SoundManagerAccessor;
import dev.lucachinou.stoppausemymusic.mixin.client.accessor.SoundSystemAccessor;
import java.util.ArrayList;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_1142;
import net.minecraft.class_1144;

public final class PersistentMusicState {
    private static class_1113 preservedMusic;

    private PersistentMusicState() {
    }

    public static boolean keepCurrentMusic(class_1142 musicTracker, class_1144 soundManager) {
        class_1113 currentMusic = ((MusicTrackerAccessor) musicTracker).stoppausemymusic$getCurrent();
        if (currentMusic == null || !soundManager.method_4877(currentMusic)) {
            clear();
            return false;
        }

        preservedMusic = currentMusic;
        return true;
    }

    public static void stopAllExceptCurrentMusic(class_1142 musicTracker, class_1144 soundManager) {
        class_1113 currentMusic = ((MusicTrackerAccessor) musicTracker).stoppausemymusic$getCurrent();
        if (currentMusic == null || !soundManager.method_4877(currentMusic)) {
            clear();
            soundManager.method_4881();
            return;
        }

        preservedMusic = currentMusic;
        class_1140 soundSystem = ((SoundManagerAccessor) soundManager).stoppausemymusic$getSoundSystem();

        for (Object sound : new ArrayList<>(((SoundSystemAccessor) soundSystem).stoppausemymusic$getSources().keySet())) {
            if (sound != currentMusic) {
                soundManager.method_4870((class_1113) sound);
            }
        }
    }

    public static boolean shouldKeepPlaying(class_1113 currentMusic, class_1144 soundManager) {
        if (preservedMusic == null) {
            return false;
        }

        if (currentMusic == preservedMusic && soundManager.method_4877(currentMusic)) {
            return true;
        }

        clear();
        return false;
    }

    public static void validate(class_1113 currentMusic, class_1144 soundManager) {
        if (preservedMusic != null && (currentMusic != preservedMusic || !soundManager.method_4877(currentMusic))) {
            clear();
        }
    }

    public static void clear() {
        preservedMusic = null;
    }
}
