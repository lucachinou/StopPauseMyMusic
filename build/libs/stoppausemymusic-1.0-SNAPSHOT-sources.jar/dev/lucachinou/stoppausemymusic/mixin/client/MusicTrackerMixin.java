package dev.lucachinou.stoppausemymusic.mixin.client;

import dev.lucachinou.stoppausemymusic.client.PersistentMusicState;
import dev.lucachinou.stoppausemymusic.mixin.client.accessor.MusicTrackerAccessor;
import net.minecraft.class_1113;
import net.minecraft.class_1142;
import net.minecraft.class_310;
import net.minecraft.class_5195;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1142.class)
public abstract class MusicTrackerMixin {
    @Shadow
    @Final
    private class_310 client;

    @Inject(method = "shouldReplace", at = @At("HEAD"), cancellable = true)
    private static void stoppausemymusic$preventTransitionReplacement(class_5195 newSound, class_1113 currentSound, CallbackInfoReturnable<Boolean> cir) {
        if (PersistentMusicState.shouldKeepPlaying(currentSound, class_310.method_1551().method_1483())) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void stoppausemymusic$clearExpiredPreservedMusic(CallbackInfo ci) {
        class_1113 currentMusic = ((MusicTrackerAccessor) this).stoppausemymusic$getCurrent();
        PersistentMusicState.validate(currentMusic, this.client.method_1483());
    }

    @Inject(method = "stop()V", at = @At("TAIL"))
    private void stoppausemymusic$clearStateAfterStop(CallbackInfo ci) {
        PersistentMusicState.clear();
    }

    @Inject(method = "stop(Lnet/minecraft/sound/MusicSound;)V", at = @At("TAIL"))
    private void stoppausemymusic$clearStateAfterTypedStop(class_5195 musicSound, CallbackInfo ci) {
        PersistentMusicState.clear();
    }
}
