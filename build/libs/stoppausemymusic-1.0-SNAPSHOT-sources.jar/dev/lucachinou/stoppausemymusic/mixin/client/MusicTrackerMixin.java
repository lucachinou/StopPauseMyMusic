package dev.lucachinou.stoppausemymusic.mixin.client;

import dev.lucachinou.stoppausemymusic.client.PersistentMusicState;
import dev.lucachinou.stoppausemymusic.mixin.client.accessor.MusicTrackerAccessor;
import net.minecraft.class_1113;
import net.minecraft.class_1142;
import net.minecraft.class_1144;
import net.minecraft.class_310;
import net.minecraft.class_5195;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1142.class)
public abstract class MusicTrackerMixin {
    @Shadow
    @Final
    private class_310 client;

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/SoundManager;stop(Lnet/minecraft/client/sound/SoundInstance;)V"))
    private void stoppausemymusic$preventTransitionReplacement(class_1144 soundManager, class_1113 currentSound) {
        if (!PersistentMusicState.shouldKeepPlaying(currentSound, soundManager)) {
            soundManager.method_4870(currentSound);
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void stoppausemymusic$clearExpiredPreservedMusic(CallbackInfo ci) {
        class_1113 currentMusic = ((MusicTrackerAccessor) this).stoppausemymusic$getCurrent();
        PersistentMusicState.validate(currentMusic, this.client.method_1483());
    }

    @Inject(method = "stop()V", at = @At("HEAD"), cancellable = true)
    private void stoppausemymusic$keepPreservedMusicOnStop(CallbackInfo ci) {
        class_1113 currentMusic = ((MusicTrackerAccessor) this).stoppausemymusic$getCurrent();
        if (PersistentMusicState.shouldKeepPlaying(currentMusic, this.client.method_1483())) {
            ci.cancel();
        }
    }

    @Inject(method = "stop(Lnet/minecraft/sound/MusicSound;)V", at = @At("HEAD"), cancellable = true)
    private void stoppausemymusic$keepPreservedMusicOnTypedStop(class_5195 musicSound, CallbackInfo ci) {
        class_1113 currentMusic = ((MusicTrackerAccessor) this).stoppausemymusic$getCurrent();
        if (PersistentMusicState.shouldKeepPlaying(currentMusic, this.client.method_1483())) {
            ci.cancel();
        }
    }
}
