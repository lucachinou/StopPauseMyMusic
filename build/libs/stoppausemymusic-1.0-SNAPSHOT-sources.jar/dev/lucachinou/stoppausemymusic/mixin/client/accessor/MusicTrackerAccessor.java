package dev.lucachinou.stoppausemymusic.mixin.client.accessor;

import net.minecraft.class_1113;
import net.minecraft.class_1142;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1142.class)
public interface MusicTrackerAccessor {
    @Accessor("current")
    class_1113 stoppausemymusic$getCurrent();
}

