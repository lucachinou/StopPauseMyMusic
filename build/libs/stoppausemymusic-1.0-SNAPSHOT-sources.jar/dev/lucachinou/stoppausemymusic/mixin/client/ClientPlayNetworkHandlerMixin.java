package dev.lucachinou.stoppausemymusic.mixin.client;

import dev.lucachinou.stoppausemymusic.client.PersistentMusicState;
import net.minecraft.class_1142;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_634.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Redirect(method = "onPlayerRespawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/MusicTracker;stop()V"))
    private void stoppausemymusic$keepMusicDuringWorldTransfer(class_1142 musicTracker) {
        if (!PersistentMusicState.keepCurrentMusic(musicTracker)) {
            musicTracker.method_4859();
        }
    }
}
