package dev.lucachinou.stoppausemymusic.mixin.client.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1113;
import net.minecraft.class_1140;

@Mixin(class_1140.class)
public interface SoundSystemAccessor {
    @Accessor("sources")
    Map<class_1113, ?> stoppausemymusic$getSources();
}

