package dev.lucachinou.stoppausemymusic.mixin.client;

import dev.lucachinou.stoppausemymusic.client.PersistentMusicState;
import net.minecraft.class_1142;
import net.minecraft.class_1144;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Shadow
    @Final
    private class_1142 musicTracker;

    @Redirect(method = "setWorld(Lnet/minecraft/client/world/ClientWorld;Z)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/SoundManager;stopAll()V"))
    private void stoppausemymusic$keepCurrentMusicPlaying(class_1144 soundManager) {
        PersistentMusicState.stopAllExceptCurrentMusic(this.musicTracker, soundManager);
    }
}

