package dev.lucachinou.stoppausemymusic.mixin.client;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    // Placeholder conservé pour compatibilité de source; non enregistré dans la config mixin 1.21.4.
}
