package dev.lucachinou.stoppausemymusic.mixin.client;

import dev.lucachinou.stoppausemymusic.client.PersistentMusicState;
import net.minecraft.class_1142;
import net.minecraft.class_1144;
import net.minecraft.class_1297;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_757;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Shadow @Final private class_1142 musicTracker;
    @Shadow @Final private class_1144 soundManager;
    @Shadow @Final public class_761 worldRenderer;
    @Shadow @Final public class_702 particleManager;
    @Shadow @Final public class_757 gameRenderer;
    @Shadow private class_2535 integratedServerConnection;

    @Shadow
    public abstract void setCameraEntity(class_1297 entity);

    @Shadow
    public abstract void updateWindowTitle();

    @Inject(method = "setWorld", at = @At("HEAD"), cancellable = true)
    private void stoppausemymusic$keepCurrentMusicPlaying(class_638 world, CallbackInfo ci) {
        PersistentMusicState.stopAllExceptCurrentMusic(this.musicTracker, this.soundManager);
        this.setCameraEntity(null);
        this.integratedServerConnection = null;
        this.worldRenderer.method_3244(world);
        this.particleManager.method_3045(world);
        this.gameRenderer.method_71112(world);
        this.updateWindowTitle();
        ci.cancel();
    }
}
