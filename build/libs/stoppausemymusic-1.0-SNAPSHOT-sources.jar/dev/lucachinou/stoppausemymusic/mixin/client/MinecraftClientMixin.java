package dev.lucachinou.stoppausemymusic.mixin.client;

import dev.lucachinou.stoppausemymusic.client.PersistentMusicState;
import net.minecraft.class_1142;
import net.minecraft.class_1144;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Shadow
    @Final
    private class_1142 musicTracker;

    @Inject(method = "joinWorld", at = @At("HEAD"))
    private void stoppausemymusic$preserveCurrentMusicBeforeJoinWorld(CallbackInfo ci) {
        PersistentMusicState.preserveCurrentMusic((class_310) (Object) this);
    }

    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screen/Screen;Z)V", at = @At("HEAD"))
    private void stoppausemymusic$preserveCurrentMusicBeforeDisconnect(net.minecraft.class_437 disconnectionScreen, boolean transferring, CallbackInfo ci) {
        PersistentMusicState.preserveCurrentMusic((class_310) (Object) this);
    }

    @Inject(method = "onDisconnected", at = @At("HEAD"))
    private void stoppausemymusic$preserveCurrentMusicBeforeDisconnectCleanup(CallbackInfo ci) {
        PersistentMusicState.preserveCurrentMusic((class_310) (Object) this);
    }

    @Redirect(method = "reset", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/SoundManager;stopAll()V"))
    private void stoppausemymusic$keepCurrentMusicPlayingDuringReset(class_1144 soundManager) {
        PersistentMusicState.stopAllExceptCurrentMusic(this.musicTracker, soundManager);
    }

    @Redirect(method = "openGameMenu", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/SoundManager;pauseAll()V"))
    private void stoppausemymusic$keepMusicPlayingInPauseMenu(class_1144 soundManager) {
        // Ne rien faire : on supprime complètement la mise en pause audio au menu pause.
    }
}
